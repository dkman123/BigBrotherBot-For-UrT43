# -*- coding: utf-8 -*-

# ################################################################### #
#                                                                     #
#  BigBrotherBot(B3) (www.bigbrotherbot.net)                          #
#  Copyright (C) 2005 Michael "ThorN" Thornton                        #
#                                                                     #
#  This program is free software; you can redistribute it and/or      #
#  modify it under the terms of the GNU General Public License        #
#  as published by the Free Software Foundation; either version 2     #
#  of the License, or (at your option) any later version.             #
#                                                                     #
#  This program is distributed in the hope that it will be useful,    #
#  but WITHOUT ANY WARRANTY; without even the implied warranty of     #
#  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the       #
#  GNU General Public License for more details.                       #
#                                                                     #
#  You should have received a copy of the GNU General Public License  #
#  along with this program; if not, write to the Free Software        #
#  Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA      #
#  02110-1301, USA.                                                   #
#                                                                     #
# ################################################################### #

__version__ = '0.1'
__author__  = 'isopropanol'

import b3
#import b3.cron
import b3.events
import b3.plugin

#from b3.clients import Client
#from b3.functions import getCmd
from ConfigParser import NoOptionError
#from b3.querybuilder import QueryBuilder
#from b3.storage import Storage
#from rcon import Rcon

class MapconfigPlugin(b3.plugin.Plugin):
	# requiresConfigFile = False
	# requiresPlugins = ['admin']

	adminPlugin = None
	powerAdminUrtPlugin = None

	requiresParsers = ['iourt42', 'iourt43']
	loadAfterPlugins = ['poweradminurt']

	####################################################################################################################
	#                                                                                                                  #
	#    STARTUP                                                                                                       #
	#                                                                                                                  #
	####################################################################################################################

	def onStartup(self):
		"""
		startup the plugin
		"""
		# get the admin plugin so we can register commands
		self.adminPlugin = self.console.getPlugin('admin')
		self.powerAdminUrtPlugin = self.console.getPlugin('powerAdminUrtPlugin')

		# register our commands
		#if 'commands' in self.config.sections():
		#	for cmd in self.config.options('commands'):
		#		level = self.config.get('commands', cmd)
		#		sp = cmd.split('-')
		#		alias = None
		#		if len(sp) == 2:
		#			cmd, alias = sp
		#
		#		func = getCmd(self, cmd)
		#		if func:
		#			self._adminPlugin.registerCommand(self, cmd, level, func, alias)

		self.registerEvent('EVT_GAME_ROUND_START', self.onNewMap)


	#
	#def onLoadConfig(self):
	#	"""
	#	load plugin configuration
	#	"""
	#	#try:
	#	#	self._immunity_level = self.config.getint('global_settings', 'immunity_level')
	#	#except (NoOptionError, ValueError):
	#	#	self._immunity_level = 100
	#
	#	#self.info('immunity level : %s' % self._immunity_level)

	####################################################################################################################
	#                                                                                                                  #
	#   EVENTS                                                                                                         #
	#                                                                                                                  #
	####################################################################################################################

	def onNewMap(self, event):
		"""
	    Handle EVT_GAME_ROUND_START.
	    """
		# self.debug('onNewMap handle %s:"%s"', event.type, event.data)
		# event.data is a b3.game.Game object
		mapName = event.data._get_mapName()
		self.debug('onNewMap map %s', mapName)
		# need to read b3 table to get values

		mapconfig = {"id": 0, "mapname": "", "capturelimit": 8, "g_suddendeath": 0, "g_gear": "0", "g_gravity": 800, "g_friendlyfire": 2 }

		mapconfig["mapname"] = mapName
		mapconfig = self.getMapconfig(mapconfig)
		if mapconfig["id"] > 0:
			# then rcon to set game values
			self.debug('setting capturelimit %s, g_gear %s' % (mapconfig["capturelimit"], mapconfig["g_gear"]))

			self.console.write('capturelimit %s ' % (mapconfig["capturelimit"]))
			self.console.write('g_suddendeath %s ' % (mapconfig["g_suddendeath"]))
			self.console.write('g_gear "%s" ' % (mapconfig["g_gear"]))
			self.console.write('g_gravity %s ' % (mapconfig["g_gravity"]))
			self.console.write('g_friendlyfire %s ' % (mapconfig["g_friendlyfire"]))
			self.debug('onNewMap updated successfully')

	# def onPlayerConnect(self, event):
	#     """
	#     Examine players ip address and allow/deny connection.
	#     """
	#     client = event.client
	#     # check the level of the connecting client before applying the filters
	#     if client.maxLevel > self._maxLevel:
	#         self.debug('%s is a higher level user and allowed to connect' % client.name)
	#     else:
	# 		dosomething


	####################################################################################################################
	#                                                                                                                  #
	#    OTHER METHODS                                                                                                 #
	#                                                                                                                  #
	####################################################################################################################


	def getMapconfig(self, mapconfig):
		"""
		Return an mapconfig object fetching data from the storage.
		:param mapconfig: The mapconfig object to fill with fetch data.
		:return: The mapconfig object given in input with all the fields set.
		"""
		# self.console.debug('Storage: getMapconfig %s' % mapconfig)
		if hasattr(mapconfig, 'mapname') and mapconfig["mapname"]:
			# query = QueryBuilder(self.db).SelectQuery('*', 'mapconfig', {'mapname': mapconfig.mapname}, None, 1)
			self.debug("has attribute mapname")
			# pass
		# else:
		# 	raise KeyError('no mapname was set %s' % mapconfig)

		# cursor = self.query(query)
		cursor = self.console.storage.query("SELECT * FROM mapconfig WHERE mapname = '%s'" % (mapconfig["mapname"]))
		if cursor.EOF:
			cursor.close()
			self.debug('no mapconfig found matching %s' % (mapconfig["mapname"]))
			mapconfig["id"] = 0
			return mapconfig
			# raise KeyError('no mapconfig found matching %s' % mapconfig.mapname)

		row = cursor.getOneRow()
		mapconfig["id"] = int(row['id'])
		mapconfig["mapname"] = row['mapname']
		mapconfig["capturelimit"] = int(row['capturelimit'])
		mapconfig["g_suddendeath"] = int(row['g_suddendeath'])
		mapconfig["g_gear"] = row['g_gear']
		mapconfig["g_gravity"] = int(row['g_gravity'])
		mapconfig["g_friendlyfire"] = int(row['g_friendlyfire'])
	
		return mapconfig

	####################################################################################################################
	#                                                                                                                  #
	#    COMMANDS                                                                                                      #
	#                                                                                                                  #
	####################################################################################################################

	# def cmd_dosomething(self, data=None, client=None, cmd=None):
	#	if not data:
	#		client.message('^7invalid data, try !help dosomething')
	#		return
	#
	#	sclient = self._adminPlugin.findClientPrompt(data, client)
	#
	#	if not sclient:
	#		# a player matching the name was not found, a list of closest matches will be displayed
	#		# we can exit here and the user will retry with a more specific player
	#		return
	#
	#	# TODO check immunity level
	#	#if sclient.
	#
	#	# -- IPHub
	#
	#	cmd.sayLoudOrPM(client, 'dosomething %s' % (sclient.cid))


